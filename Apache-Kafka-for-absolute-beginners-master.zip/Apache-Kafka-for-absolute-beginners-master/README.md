# Apache-Kafka-for-absolute-beginners
Apache Kafka for absolute beginners by Packt Publishing
